#!/usr/bin/env python
#coding=utf8

"""
    文件名包含明显的木马名字和已知webshell名列表
"""

php_webshell = [
"phpspy.php",
"yijuhua.php",
"houmeng.php",
"backdoor.php",
"后门.php",
"xxoo.php",
"一句话.php"
]

asp_webshell = [
]

aspx_webshell = [
]

jsp_webshell = [
]
