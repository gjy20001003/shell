#/usr/bin/env python
#coding=utf8

"""
    后门中包含的特有敏感字符
    自行手动添加各个类型后门到字典中，格式{"关键字":"类型"}
"""

#php敏感字符列表
php_sensitive_words = {
    "www.phpdp.org":"PHP神盾加密后门",
    "www.phpjm.net":"PHP加密后门"
}

asp_sensitive_words = {
}

apsx_sensitive_words = {
}

jsp_sensitive_words = [
]
